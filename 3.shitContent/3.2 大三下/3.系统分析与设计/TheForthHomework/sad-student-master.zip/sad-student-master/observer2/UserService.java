
public class UserService {

    public long register(String telephone, String password) {
        System.out.println("新用户注册完成");
        return 100;
    }

}
