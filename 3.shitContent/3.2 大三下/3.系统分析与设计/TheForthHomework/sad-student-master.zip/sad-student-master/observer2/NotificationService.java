
public class NotificationService {

    public void sendInboxMessage(long userId, String string) {
        System.out.println("用户" + userId + "," + string);
    }

}
