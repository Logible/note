
public class PromotionService {

    public void issueNewUserExperienceCash(long userId) {
        System.out.println("发放新用户体验金给用户" + userId);
    }

}
