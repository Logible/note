
public interface RegObserver {

    void handleRegSuccess(long userId);

}
