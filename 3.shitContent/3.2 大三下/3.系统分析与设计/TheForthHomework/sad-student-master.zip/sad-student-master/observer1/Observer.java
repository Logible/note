/** 表示观察者的接口 */
public interface Observer {
	void update(NumberGenerator generator);
}
