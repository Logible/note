

public class XmlRuleConfigParser implements IRuleConfigParser {

    @Override
    public RuleConfig parse(String configText) {
        // TODO Auto-generated method stub
        return null;
    }

}
