

public interface IRuleConfigParser {

    RuleConfig parse(String configText);

}
