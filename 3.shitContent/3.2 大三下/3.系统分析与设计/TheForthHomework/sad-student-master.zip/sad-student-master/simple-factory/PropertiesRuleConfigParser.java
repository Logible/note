

public class PropertiesRuleConfigParser implements IRuleConfigParser {

    @Override
    public RuleConfig parse(String configText) {
        // TODO Auto-generated method stub
        return null;
    }

}
