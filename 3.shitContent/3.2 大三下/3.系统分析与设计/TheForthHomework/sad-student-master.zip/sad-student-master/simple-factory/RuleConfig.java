

public class RuleConfig {

}
