

public class InvalidRuleConfigException extends Throwable {

    public InvalidRuleConfigException(String string) {
    }

}
