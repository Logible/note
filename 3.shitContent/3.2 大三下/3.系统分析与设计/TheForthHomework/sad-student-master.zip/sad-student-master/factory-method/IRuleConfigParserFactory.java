public interface IRuleConfigParserFactory {
    IRuleConfigParser createParser();
}
